
function inicar_sistema(){
	 robots(1,null);
}


function robots(id,objeto){
	if(id==1){listarcontatos_locais();}		
}




//function robots(nome_div, classe, metodo, nome_div_destino, parametros,script) {
//	var hora;
//	var horaIni;
//	hora = new Date();
//	horaIni = hora.getTime();

//    $.ajax({
//        type: "POST",
//        url : url+'controle',
//        dataType: "xml",
//        data : parametros,
//        success: function (xml) {
//		hora = new Date();
//		horaFim = (hora.getTime() - horaIni);
//		if ($('#zeroone').length > 0) {
//			document.getElementById('zeroone').innerHTML = (horaFim / 1000);
//		}
		
//		$(xml).find('nanobot').each(function() {
//			var codigo = $(this).find('codigo').text();
//            if (codigo == 903) {alerta_nanobot($(this));}
//		});    
        
//        },
//        error: function () {
//            alert("Ocorreu um erro inesperado durante o processamento.");
//        }
//    });
//}





