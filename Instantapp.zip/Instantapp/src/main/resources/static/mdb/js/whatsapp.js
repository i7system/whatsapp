
function listarcontatos1() {	
	  y=(window.innerHeight-148);
	  $('#contatos').html('');	  
	  	  
  	x='<div class="row p-0 m-0">'+
	  '<div class="col-12 p-0 m-0">'+
      '<div class="cabec2 m-0 pt-2 pr-3 pl-3 " style="border-bottom: 1px solid #E4E5E6;">'+
	  '<div class="p-1" style="background-color: #fff; border-radius: 18px;">'+
	  '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"> <path fill="#263238" fill-opacity=".3" d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"></path></svg>'+
	  '<img onclick="pesquisa_mulheres();" src="img/mulher_branco.png" style=" width: 24px; height: 24x; border-radius: 50%;">'+
	  '<img class="ml-1 mr-2" onclick="pesquisa_homens();" src="img/homem_branco.png"  style=" width: 24px; height: 24x; border-radius: 50%;">'+
	  '<input id="txt_procurar" class="pl-2" style="width: 60%; border: none;" type="text" placeholder="Procurar" onkeyup="pesquisa_filtro();">'+
	  '</div>'+
	  '</div>'+
      '</div></div>';
	 $('#contatos').append(x);
	  
	 var x='<div class="text-center mao" style="border-bottom: 1px solid #E4E5E6; background-color:#F8F8F8;" onclick="listarcontatos_locais();"><h5 class="pt-2" >Ver conversas</h5></div>';			
	 $('#contatos').append(x);     	
	  

	  var x='<div id="contatos1" style="overflow: auto; height:'+y+'px;"></div>';			
	  $('#contatos').append(x);     	 
	  
	  for (w = 1; w <=1; w++){	 
	  $.getJSON( url+'listarcontatosempresa'+w, '' , {format: 'json'})
	   .done(function(data) {		    
	    qtde=data.length;	
	    
	    for (i = 0; i < qtde; i++){	 
	    	IDUSUARIO = data[i][0];
	    	NOME      = data[i][1];
	    	FOTO      = data[i][2];
	    	SEXO      = data[i][3];
	    	FRASE     = data[i][4];
	    	LATITUDE  = data[i][5];
	    	LONGITUDE = data[i][6];
	    
	    	
		x='<div class="cabec3 p-0 m-0 mao" data-id="'+IDUSUARIO+'" data-sexo="'+SEXO+'" data-latitude="'+LATITUDE+'" data-longitude="'+LONGITUDE+'" id="user_'+IDUSUARIO+'">'+	
		   '<div class="row m-0 p-0">'+ 
		   '<div class="col-3 m-0 p-0 text-center">'+
		   '<i class=" waves-effect waves-light"><img class="btn-floating btn-fb waves-effect waves-light" id="usuario_foto" style="width: 54px; height: 54px; " src="'+FOTO+'"></i>'+
		   '</div>'+
		   '<div class="col-9 m-0 p-0"><strong><h5 class="p-0 m-0 pt-3 nomecontato ">'+NOME+'</h5></strong><small class="frase">'+FRASE+'</small></div>'+
		   '</div>'+
		   '</div>';	
		   $('#contatos1').append(x); 
	   }
      });
	  }
};



function listarcontatos2() {	
	  
	  for (w = 2; w <=2; w++){	 
	  $.getJSON( url+'listarcontatosempresa'+w, '' , {format: 'json'})
	   .done(function(data) {		    
	    qtde=data.length;	
	    
	    for (i = 0; i < qtde; i++){	 
	    	IDUSUARIO = data[i][0];
	    	NOME      = data[i][1];
	    	FOTO      = data[i][2];
	    	SEXO      = data[i][3];
	    	FRASE     = data[i][4];
	    	LATITUDE  = data[i][5];
	    	LONGITUDE = data[i][6];
		   
			x='<div class="cabec3 p-0 m-0 mao" data-id="'+IDUSUARIO+'" data-sexo="'+SEXO+'" data-latitude="'+LATITUDE+'" data-longitude="'+LONGITUDE+'" id="user_'+IDUSUARIO+'">'+	
			   '<div class="row m-0 p-0">'+ 
			   '<div class="col-3 m-0 p-0 text-center">'+
			   '<i class=" waves-effect waves-light"><img class="btn-floating btn-fb waves-effect waves-light" id="usuario_foto" style="width: 54px; height: 54px; " src="'+FOTO+'"></i>'+
			   '</div>'+
			   '<div class="col-9 m-0 p-0"><strong><h5 class="p-0 m-0 pt-3 nomecontato ">'+NOME+'</h5></strong><small class="frase">'+FRASE+'</small></div>'+
			   '</div>'+
			   '</div>';	
			   $('#contatos1').append(x); 	   
		   
		   
	   }
      });
	  }
};


function listarcontatos_locais() {	
	

	
	   x='<div class="row m-0 p-0" style="height: 100%; display: block;" id="inicio">'+
		 '<div class="col-lg-12" style="height: 100%;">'+
		 '<h1 class="pt-5 text-center" style="height: 50%;"><img src="mdb/img/outras/whatsapp.jpg" style="width: 250px; height: 250px;"></h1>'+
		 '<h3 class="titulo01 text-center" style="height: 10%;">Mantenha seu celular conectado</h3>'+
		 '<p class="titulo02 text-center" style="height: 10%;">'+
		 'O InstantApp conecta ao seu telefone para sincronizar suas mensagens.<br> Para reduzir o uso de dados, conecte seu telefone a uma rede Wi-Fi.'+
		 '</p>'+
		 '<hr class="pt-2 pb-2">'+
		 '<p class="titulo02 text-center" style="height: 10%;">'+
		 '<svg id="Layer_1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21 18" width="21" height="18"> <path fill="#9DA3A5" d="M10.426 14.235a.767.767 0 0 1-.765-.765c0-.421.344-.765.765-.765s.765.344.765.765-.344.765-.765.765zM4.309 3.529h12.235v8.412H4.309V3.529zm12.235 9.942c.841 0 1.522-.688 1.522-1.529l.008-8.412c0-.842-.689-1.53-1.53-1.53H4.309c-.841 0-1.53.688-1.53 1.529v8.412c0 .841.688 1.529 1.529 1.529H1.25c0 .842.688 1.53 1.529 1.53h15.294c.841 0 1.529-.688 1.529-1.529h-3.058z"></path></svg>'+
		 'O InstantApp está disponível para todas as plataformas. bom dia'+ 
		 '</p>'+
	     '</div></div>';	  
	     $('#corpo_home').html(x);
	     $('#conversa').hide();
	     $('#corpo_home').show();
	
	getAllDB(function (itens) {
	    var len = itens.length;
	    if(len==0){
	    	$('#contatos').html('');
	    	$('#contatos').css('overflow','hidden');
	    	y=(window.innerHeight-59);
			
			x='<section style="height:'+y+'px; background-color: #1EBEA5;">'+
			   '<div class="row p-0 m-0" style="height:40%;"><div class="col-12 p-0 m-0">'+
			   '<img src="mdb/img/outras/whatsapp1.png" width="100%">'+
			   '</div></div>'+
			   '<div class="row p-0 m-0 align-items-center justify-content-center" style="height:20%;">'+
			   '<div class="col-12 p-0 m-0">'+
			   '<h3 class="titulo01 pb-2 text-center" style="color:#fff">Bem Vindo(a) !</h3>'+
			   '</div></div>'+
			   '<div class="row p-0 m-0 align-items-center justify-content-center" style="height:30%;">'+
			   '<div class="col-12  p-0 m-0">'+
			   '<p class="titulo02 pb-2 text-center m-2" style="color:#fff">Selecione seus contatos e converse a vontade, tudo aqui é criptrografado e seguro.</p>'+
				'<hr>'+
				'</div></div>'+
				'<div class="row p-0 m-0 align-items-center justify-content-center" style="height:10%;">'+
				'<div class="col-12  p-0 m-0">'+
				'<p class="titulo02 pb-2 text-center" style="color:#fff" onclick="$(|#botao_contatos|).click();">'+
				'<strong>'+
				'<svg id="Layer_1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="25" height="25">'+
			    '<path opacity=".55" fill="#fff" d="M19.005 3.175H4.674C3.642 3.175 3 3.789 3 4.821V21.02l3.544-3.514h12.461c1.033 0 2.064-1.06 2.064-2.093V4.821c-.001-1.032-1.032-1.646-2.064-1.646zm-4.989 9.869H7.041V11.1h6.975v1.944zm3-4H7.041V7.1h9.975v1.944z"></path></svg>'+
				'Veja seus contatos <a href="javascript:void(0);"><strong>Converse agora !</strong></a>'+
			    '</strong>'+
				'</p>'+	
				'</div></div></section>';
			  $('#contatos').append(replaceAll(x,"|","'")); 
	    }	    
	    
	    if(len>0){
	    $('#contatos').html('');
    	$('#contatos').css('overflow','auto');
	   
    	
    	x='<div class="row p-0 m-0">'+
		'<div class="col-12 p-0 m-0">'+
	    '<div class="cabec2 m-0 pt-2 pr-3 pl-3 " style="border-bottom: 1px solid #E4E5E6;">'+
		'<div class="p-1" style="background-color: #FFFFFF; border-radius: 18px;">'+
		'<a href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"> <path fill="#263238" fill-opacity=".3" d="M15.009 13.805h-.636l-.22-.219a5.184 5.184 0 0 0 1.256-3.386 5.207 5.207 0 1 0-5.207 5.208 5.183 5.183 0 0 0 3.385-1.255l.221.22v.635l4.004 3.999 1.194-1.195-3.997-4.007zm-4.808 0a3.605 3.605 0 1 1 0-7.21 3.605 3.605 0 0 1 0 7.21z"></path></svg></a>'+
		'<img class="mao" src="img/mulher_branco.png" onclick="pesquisa_mulheres();" style=" width: 24px; height: 24x; border-radius: 50%;">'+
		'<img class="ml-1 mr-2 mao" src="img/homem_branco.png" style=" width: 24px; height: 24x; border-radius: 50%;" onclick="pesquisa_homens();">'+
		'<input id="txt_procurar" class="pl-2" style="width: 70%; border: none;" type="text" placeholder="Procurar" onkeyup="pesquisa_filtro();">'+
		'</div>'+
		'</div>'+
	    '</div></div>';
		 $('#contatos').append(x);
    	
  	  var x='<div id="contatos1"></div>';			
	  $('#contatos').append(x);  
    	
	    for (var i = 0; i < len; i += 1) {
	    	IDCONTATO=itens[i].IDCONTATO;
	    	IDUSUARIO= itens[i].IDUSUARIO;
	    	NOME= itens[i].NOME;
	    	FOTO=itens[i].FOTO;
	        DATA=itens[i].DATA;
	        ULTIMA=itens[i].ULTIMA;
	        QTDE=itens[i].QTDE;
 	    	LONGITUDE=itens[i].LONGITUDE;
 	    	LATITUDE=itens[i].LATITUDE; 	
 	    	SEXO=itens[i].SEXO;
 	   	    FRASE=itens[i].FRASE;
	        
			// atualiza barra de contatos
			
			x='<div class="cabec3 p-0 m-0 mao" data-id="'+IDUSUARIO+'" data-sexo="'+SEXO+'" data-latitude="'+LATITUDE+'" data-longitude="'+LONGITUDE+'" id="user_'+IDUSUARIO+'">'+	
	 		      '<div class="row m-0 p-0">'+ 
	 		      '<div class="col-3 mt-0 p-0 text-center">'+
	 			  '<i class=" waves-effect waves-light"><img class="btn-floating btn-fb waves-effect waves-light" id="usuario_foto" style="width: 54px; height: 54px; " src="'+FOTO+'"></i>'+
	 		      '</div>'+
                  '<div class="col-9 m-0 p-0">'+
			      '<div class="row m-0 p-0 ">'+
			      '<div class="col-9 p-0 m-0 pt-3"><strong><h5 class="p-0 m-0 nomecontato ">'+NOME+'</h5></strong></div>'+
			      '<div class="col-3 p-0 m-0 pt-3 pr-3"><small class="float-right" style="color:#9B9B9B;">'+hora(DATA)+'</small></div>'+
			      '</div>'+
			      '<div class="row m-0 p-0 ">'+
			      '<div class="col-9 p-0 m-0"><small style="color:gray;">'+ULTIMA+'</small><small class="frase" style="display:none;">'+FRASE+'</small></div>'+
			      '<div class="col-3 p-0 m-0 pr-3"><span class="badge green float-right" style=" border-radius: 18px; min-width: 20px; min-height: 20px; padding-top: 4px; " >'+QTDE+'</span></div>'+
			      '</div>'+
                  '</div>'+
                  '</div>'+
                  '</div>';
     	        
	   $('#contatos1').append(x);                
       }}},'whatsappusuarios');	 
	
	if(largura_tela>=1200){
		$('#corpo').show();
		$('#barra_esquerda').show();	
		$('#barra_direita').hide();
	} else {
		$('#barra_esquerda').show();	
		$('#barra_direita').hide();
		$('#corpo').hide();
	}
	
	
};

//nanobots -> carregar conversas
function carregarconversa(objeto) {

	foto=$(objeto).find("img").attr("src");
	nome=$(objeto).find("h5").html();
 	longitude=$(objeto).data('longitude');
 	latitude=$(objeto).data('latitude'); 	
 	sexo=$(objeto).data('sexo');
	frase=$(objeto).find(".frase").html();
	id=$(objeto).data('id');
	
	$('#emoji_grupo').hide();
	$('#conversa_id').html(id);	
	$('#conversa_nome').html(nome);
	$('#conversa_foto').attr("src",foto);
	$('#conversa_frase').html(frase);
	x=(window.innerHeight-104);	
	$('#conversa_conteudo').html('');
	$('#conversa_conteudo').css('height',x+'px');	
	$('#conversa_conteudo').prop("scrollTop",$('#conversa_conteudo').prop("scrollHeight"));
	
	if(largura_tela>=1200){
		$('#corpo').show();
		$('#barra_esquerda').show();	
		//$('#barra_direita').hide();
	} else {
		$('#barra_esquerda').hide();	
		//$('#barra_direita').hide();
		$('#corpo').show();
	}
	
	$('#inicio').hide();
	$('#conversa').show();	
	$('#mensagemzap').html('');
	$('#mensagemzap').focus();
	
	$('#info_nome').html(nome);
	$('#info_foto').attr("src",replaceAll(foto,"_mini",""));
	$('#info_frase').html(frase);
	
    getUnico(function (itens) {
  	    var len = itens.length;
  	    if(len>0){
  	    	crud(2,'whatsappusuarios',{IDCONTATO:itens[0].IDCONTATO,IDUSUARIO:id, NOME:itens[0].NOME, FOTO:itens[0].FOTO,DATA:itens[0].DATA,ULTIMA:itens[0].ULTIMA,QTDE:0,LATITUDE:latitude,LONGITUDE:longitude,SEXO:sexo,FRASE:frase},'');
   	    } 	  
      },'whatsappusuarios',id);
   	$('#user_'+id+' span').html('0');
   	
	getporindex(function (itens) {
		var len = itens.length;		
		for (var i = 0; i < len; i += 1) {		
			TIPO= itens[i].TIPO;
			MENSAGEM=itens[i].MENSAGEM;		
			if(itens[i].IDDESTINATARIO==id_usuario){		
					y="<div class='row p-0 m-0'><div class='col-lg-12'><small class='card-text cr1 pt-2 pb-2 pl-3 pr-3 m-2 float-left'>"+MENSAGEM+"</small></div></div>";		
					$("#conversa_conteudo").append(y);	
			} else {
					y="<div class='row p-0 m-0'><div class='col-lg-12'><small class='card-text cr2 pt-2 pb-2 pl-3 pr-3 m-2 float-right'>"+MENSAGEM+"<span class='ml-2'><svg id='Layer_1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 15' width='16' height='15'><path fill='#4FC3F7' d='M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.064-.512zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z'></path></svg></span></small></div></div>";		
					$("#conversa_conteudo").append(y);	
			}		
		}	
		
		//var div = $('#conversa_conteudo');
		//div.prop("scrollTop", div.prop("scrollHeight"));
		$('#conversa_conteudo').prop("scrollTop",$('#conversa_conteudo').prop("scrollHeight"));
		
       },'whatsappconversas','IDCONTATO',id);		
}



//nanobots -> inserir conversas
function inserirconversa(id,rementente,destinatario,tipo,mensagem,data,nome,foto,idcontato,latitude,longitude,sexo,frase) {
	
	conversa_id=$('#conversa_id').html();
		
	// escreve na tela de conversa
	if(id_usuario == destinatario && rementente == conversa_id){			
		if(conversa_id==rementente){		
			y="<div class='row p-0 m-0'><div class='col-lg-12'><small class='card-text cr1 pt-2 pb-2 pl-3 pr-3 m-2 float-left'>"+mensagem+"</small></div></div>";		
			$("#conversa_conteudo").append(y);	
			$('#conversa_conteudo').prop("scrollTop",$('#conversa_conteudo').prop("scrollHeight"));
		}	
	}	
	
	if(id_usuario == rementente && destinatario == conversa_id){
		if(conversa_id==destinatario){		
			y="<div class='row p-0 m-0'><div class='col-lg-12'><small class='card-text cr2 pt-2 pb-2 pl-3 pr-3 m-2 float-right'>"+mensagem+"<span class='ml-2'><svg id='Layer_1' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 15' width='16' height='15'><path fill='#4FC3F7' d='M15.01 3.316l-.478-.372a.365.365 0 0 0-.51.063L8.666 9.879a.32.32 0 0 1-.484.033l-.358-.325a.319.319 0 0 0-.484.032l-.378.483a.418.418 0 0 0 .036.541l1.32 1.266c.143.14.361.125.484-.033l6.272-8.048a.366.366 0 0 0-.064-.512zm-4.1 0l-.478-.372a.365.365 0 0 0-.51.063L4.566 9.879a.32.32 0 0 1-.484.033L1.891 7.769a.366.366 0 0 0-.515.006l-.423.433a.364.364 0 0 0 .006.514l3.258 3.185c.143.14.361.125.484-.033l6.272-8.048a.365.365 0 0 0-.063-.51z'></path></svg></span></small></div></div>";		
			$("#conversa_conteudo").append(y);
			$('#conversa_conteudo').prop("scrollTop",$('#conversa_conteudo').prop("scrollHeight"));
		}
	}		
	
	// registra a conversa no banco local	
    if(id_usuario==rementente){
    	   crud(1,'whatsappconversas',{IDCONTATO:destinatario,IDUSUARIO:rementente,IDDESTINATARIO:destinatario,IDTIPOCONVERSA:1,STATUS:1,IDCONVERSA:id,DATA:data,MENSAGEM:mensagem,TIPO: 1},'');   	   
    }     
    
    if(id_usuario==destinatario){
 	   crud(1,'whatsappconversas',{IDCONTATO:rementente,IDUSUARIO:rementente,IDDESTINATARIO:destinatario,IDTIPOCONVERSA:1,STATUS:1,IDCONVERSA:id,DATA:data,MENSAGEM:mensagem,TIPO: 1},'');   	   
 }     
  
    
    // registra usuario   
    if(destinatario==id_usuario){
    getUnico(function (itens) {
     	 var len = itens.length;
     	   if(len==0){
     	     qtde=1;
      	  	if(conversa_id==rementente){qtde=0;} 	  
      	     crud(1,'whatsappusuarios',{IDCONTATO:idcontato,IDUSUARIO:rementente, NOME:nome, FOTO:foto,DATA:data,ULTIMA:mensagem,QTDE:qtde,LATITUDE:latitude,LONGITUDE:longitude,SEXO:sexo,FRASE:frase},'');
           }  
     	    else {
     	    	qtde=itens[0].QTDE+1; 
          	  	if(conversa_id==rementente){qtde=0;} 
     	    	crud(2,'whatsappusuarios',{IDCONTATO:itens[0].IDCONTATO,IDUSUARIO:rementente, NOME:nome, FOTO:foto,DATA:data,ULTIMA:mensagem,QTDE:qtde,LATITUDE:latitude,LONGITUDE:longitude,SEXO:sexo,FRASE:frase},'');
     	    }
     	   
     	    $('#welcome').remove(); 
     	    if($('#contatos1').length>0){
 	    	$('#user_'+rementente).remove();  	    	
			x='<div class="cabec3 p-0 m-0 mao" data-id="'+rementente+'" data-sexo="'+sexo+'" data-latitude="'+latitude+'" data-longitude="'+longitude+'" id="user_'+rementente+'">'+	
		      '<div class="row m-0 p-0">'+ 
		      '<div class="col-3 mt-0 p-0 text-center">'+
			  '<i class=" waves-effect waves-light"><img class="btn-floating btn-fb waves-effect waves-light" id="usuario_foto" style="width: 54px; height: 54px; " src="'+foto+'"></i>'+
		      '</div>'+
              '<div class="col-9 m-0 p-0">'+
		      '<div class="row m-0 p-0 ">'+
		      '<div class="col-9 p-0 m-0 pt-3"><strong><h5 class="p-0 m-0 nomecontato ">'+nome+'</h5></strong></div>'+
		      '<div class="col-3 p-0 m-0 pt-3 pr-3"><small class="float-right" style="color:#9B9B9B;">'+hora(data)+'</small></div>'+
		      '</div>'+
		      '<div class="row m-0 p-0 ">'+
		      '<div class="col-9 p-0 m-0"><small style="color:gray;">'+mensagem+'</small><small class="frase" style="display:none;">'+frase+'</small></div>'+
		      '<div class="col-3 p-0 m-0 pr-3"><span class="badge green float-right" style=" border-radius: 18px; min-width: 20px; min-height: 20px; padding-top: 4px; " >'+qtde+'</span></div>'+
		      '</div>'+
              '</div>'+
              '</div>'+
              '</div>'; 		   
	 		  $('#contatos1').prepend(x); 		   
     	    }
     	    else
     	    {
     	    	listarcontatos_locais();
     	    }
		   
	 		  
	 		  

         },'whatsappusuarios',rementente);
  }  
}



function rapariga(){
	
	var conteudo = $('#mensagemzap').html().trim();
	var iddestinatario = parseInt($('#conversa_id').html().trim());
	var nome = $('#conversa_nome').html().trim();
	var foto = $('#conversa_foto').attr("src");	
 	var longitude=$('#user_'+iddestinatario).data('longitude');
 	var latitude=$('#user_'+iddestinatario).data('latitude'); 	
 	var sexo=$('#user_'+iddestinatario).data('sexo');
	var frase=$('#conversa_frase').html().trim();	
	var data = dataAtualFormatada();
	var idcontado =0;	
	
	$('#mensagemzap').html('');
	var qtde=0;
	
if(conteudo!=''){
	if(conteudo && stompClient) {

		getUnico(function (itens) {
			var len = itens.length;
			
			if(len==0){			
				z={ IDCONTATO:0, IDUSUARIO:id_usuario, IDUSUARIOCONTATO:iddestinatario, DATA:data, MENSAGEM:conteudo, QTDE:0};
				$.getJSON( url+'gravarcontato', z , {format: 'json'}).done(function(message) {
				   crud(1,'whatsappusuarios',{IDCONTATO:message.idcontato,IDUSUARIO:iddestinatario, NOME:nome, FOTO:foto,DATA:data,ULTIMA:conteudo,QTDE:0,LATITUDE:latitude,LONGITUDE:longitude,SEXO:sexo,FRASE:frase},'');
				});	
								
				z={ IDCONTATO:0, IDUSUARIO:iddestinatario, IDUSUARIOCONTATO:id_usuario, DATA:data, MENSAGEM:conteudo, QTDE:1,LATITUDE:latitude,LONGITUDE:longitude,SEXO:sexo,FRASE:frase};
				$.getJSON( url+'gravarcontato', z , {format: 'json'}).done(function(message) {
					idcontato=message.idcontato;
					var chatMessage = {
						    idcontato: idcontato,
							idusuario: id_usuario,
							nome: nome_usuario,
							foto: foto_usuario,
							conteudo: conteudo,
							iddestinatario: iddestinatario,
							idtipomensagem: 1,
							data: data,
                            latitude: latitude_usuario,
						    longitude: longitude_usuario,
						    sexo: sexo_usuario,
						    frase:frase_usuario,
							type: 'CHAT'};	
					stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
				});	
			} 
			else
			{				
				var chatMessage = {
					    idcontato: itens[0].IDCONTATO,
						idusuario: id_usuario,
						nome: nome_usuario,
						foto: foto_usuario,
						conteudo: conteudo,
						iddestinatario: iddestinatario,
						idtipomensagem: 1,
						data: data,
						latitude: latitude,
					    longitude: longitude,
					    sexo: sexo_usuario,
					    frase:frase_usuario,
						type: 'CHAT'};		
				stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));				
				
				// atualiza qtde e mensagem do remetente 				
				z={ IDCONTATO:itens[0].IDCONTATO, IDUSUARIO:id_usuario, IDUSUARIOCONTATO:iddestinatario, DATA:data, MENSAGEM:conteudo, QTDE:0};
				$.getJSON( url+'gravarcontato', z , {format: 'json'}).done(function(message) {
				   crud(2,'whatsappusuarios',{IDCONTATO:itens[0].IDCONTATO,IDUSUARIO:iddestinatario, NOME:nome, FOTO:foto,DATA:data,ULTIMA:conteudo,QTDE:0,LATITUDE:latitude,LONGITUDE:longitude,SEXO:sexo,FRASE:frase},'');
				});					
				
				z={ IDUSUARIO:id_usuario, IDUSUARIOCONTATO:iddestinatario,DATA:data,ULTIMA:conteudo};								
				$.getJSON( url+'somarqtdecontato', z , {format: 'json'}).done(function(message){});						
			}	
			
			
			// atualiza barra de contatos			
     	    $('#welcome').remove(); 
 	    	$('#user_'+iddestinatario).remove();  
	 		   
				x='<div class="cabec3 p-0 m-0 mao" data-id="'+iddestinatario+'" data-sexo="'+sexo+'" data-latitude="'+latitude+'" data-longitude="'+longitude+'" id="user_'+iddestinatario+'">'+	
	 		      '<div class="row m-0 p-0">'+ 
	 		      '<div class="col-3 mt-0 p-0 text-center">'+
	 			  '<i class=" waves-effect waves-light"><img class="btn-floating btn-fb waves-effect waves-light" id="usuario_foto" style="width: 54px; height: 54px; " src="'+foto+'"></i>'+
	 		      '</div>'+
                  '<div class="col-9 m-0 p-0">'+
			      '<div class="row m-0 p-0 ">'+
			      '<div class="col-9 p-0 m-0 pt-3"><strong><h5 class="p-0 m-0 nomecontato ">'+nome+'</h5></strong></div>'+
			      '<div class="col-3 p-0 m-0 pt-3 pr-3"><small class="float-right" style="color:#9B9B9B;">'+hora(data)+'</small></div>'+
			      '</div>'+
			      '<div class="row m-0 p-0 ">'+
			      '<div class="col-9 p-0 m-0"><small style="color:gray;">'+conteudo+'</small><small class="frase" style="display:none;">'+frase+'</small></div>'+
			      '<div class="col-3 p-0 m-0 pr-3"><span class="badge green float-right" style=" border-radius: 18px; min-width: 20px; min-height: 20px; padding-top: 4px; " >'+qtde+'</span></div>'+
			      '</div>'+
                  '</div>'+
                  '</div>'+
                  '</div>'; 		   
		 		  $('#contatos1').prepend(x); 
		 		  $('#contatos1').prop("scrollTop",0);
	 		   
	 		   
			
		},'whatsappusuarios',iddestinatario);        	    
	}	
}
}
	
function carregar_conversas_servidor(){		
	  $.getJSON( url+'listarconversas', {idconversa: id_conversa, idusuario: id_usuario} , {format: 'json'})
	   .done(function(data) {	
	    qtde=data.length;	
	    for (i = 0; i < qtde; i++){    	
	    	if(id_usuario==data[i].idusuario){
		    	crud(1,'whatsappconversas',{IDCONTATO:data[i].idusuariodestinatario,IDUSUARIO:data[i].idusuario,IDDESTINATARIO:data[i].idusuariodestinatario,IDTIPOCONVERSA:data[i].idtipoconversa,STATUS:data[i].status,IDCONVERSA:data[i].idconversa,DATA:left(data[i].data,19)+'Z',MENSAGEM:data[i].mensagem,TIPO: 1},'');		    		
	    	} 	else 	{
		    	crud(1,'whatsappconversas',{IDCONTATO:data[i].idusuario,IDUSUARIO:data[i].idusuario,IDDESTINATARIO:data[i].idusuariodestinatario,IDTIPOCONVERSA:data[i].idtipoconversa,STATUS:data[i].status,IDCONVERSA:data[i].idconversa,DATA:left(data[i].data,19)+'Z',MENSAGEM:data[i].mensagem,TIPO: 2},'');		    				    		
	    	}    	
	   }	    
	    if(qtde>0){
	      crud(2,'whatsappcontadores',{IDUSUARIO:id_usuario, IDCONVERSA:data[qtde-1].idconversa, DATA:left(data[qtde-1].data,19)+'Z'},'');
	    }	    
 });	
}	

function carregar_contatos_servidor() {
	
	  var dfd = $.Deferred();		
	  $.getJSON( url+'listarcontatospordata', { idusuario: id_usuario ,data:id_data} , {format: 'json'})
	   .done(function(data) {		    
	    qtde=data.length;

	    for (i = 0; i < qtde; i++){	
	    	
	    	xIDCONTATO=data[i][0];
	    	xIDUSUARIO=data[i][2];
	    	xDATA=data[i][3];
	    	xULTIMA=data[i][4];
	    	xQTDE=data[i][5];
	    	xNOME=data[i][6];
	    	xFOTO=data[i][7];	
	    	xLATITUDE=data[i][8];
	    	xLONGITUDE=data[i][9];
	    	xFRASE=data[i][10];
	    	xSEXO=data[i][11];
	    	
	    	if(id_data<=xDATA){
	    		id_data=xDATA;
	    	}	    
	    	
	    	crud(1,'whatsappusuarios',{IDCONTATO:xIDCONTATO, IDUSUARIO:xIDUSUARIO, NOME:xNOME, FOTO:xFOTO,DATA:left(xDATA,19)+'Z',ULTIMA:xULTIMA,QTDE:xQTDE,LATITUDE:xLATITUDE,LONGITUDE:xLONGITUDE,SEXO:xSEXO,FRASE:xFRASE},'');
	     }	
	    
		crud(2,'whatsappcontadores',{IDUSUARIO:id_usuario, IDCONVERSA:id_conversa, DATA:left(id_data,19)+'Z'},'');
	    
	    //setTimeout(function() {
	    //	listarcontatos_locais();
		//}, 2000);
	    
       });	  
}	

$(function() {
	$("#contatos").on("click", ".cabec3", function() {
		carregarconversa(this);
	});
});

$(function() {
	$(".emojik").on("click", function() {
		classe=$(this).attr("class");
		estilo=$(this).attr("style");
		x='<img class="'+classe+'" data-emoji-index="0" style="'+estilo+' transform: scale(0.625); "/>';
		$('#mensagemzap').append(x);
	});
});

$(function() {
	$("#emoji").on("click", function() {
		if($('#emoji_grupo').css('display')=='none'){
		  $('#emoji_grupo').show();		  
		  x=$('#conversa_conteudo').height()-230;
		  $('#conversa_conteudo').css('height',x+'px');
		  $('#conversa_conteudo').prop("scrollTop",$('#conversa_conteudo').prop("scrollHeight"));
		} else {
		  $('#emoji_grupo').hide();
		  x=$('#conversa_conteudo').height()+230;
		  $('#conversa_conteudo').css('height',x+'px');
		  $('#conversa_conteudo').prop("scrollTop",$('#conversa_conteudo').prop("scrollHeight"));
		}
	});
});

$(function() {
	$("#info_fechar").on("click", function() {
		$('#corpo').removeClass("col-lg-6");
		$('#corpo').addClass("col-lg-9");
		$('#barra_direita').hide();
	});
});

$(function() {
	$("#usuario_link").on("click", function() {
		
		if($('#barra_direita').css('display')=='none'){
			$('#corpo').removeClass("col-lg-9");
			$('#corpo').addClass("col-lg-6");
			$('#barra_direita').show();			
		} else {
			$('#corpo').removeClass("col-lg-6");
			$('#corpo').addClass("col-lg-9");
			$('#barra_direita').hide();
		}

	});
});

function pesquisa_filtro(){
		filtro=$('#txt_procurar').val().toUpperCase();		
		$('#contatos .cabec3').each(function(index, element) {			
			 a=$(element).find('h5').html().toUpperCase();			
			 b=$(element).attr("id"); 
			 c=a.indexOf(filtro);	
			 d=$(element).find('small').html().toUpperCase();
			 e=d.indexOf(filtro);
			 if(c==-1 && e==-1){$('#'+b).hide();} else {$('#'+b).show();}	
	});
};

function pesquisa_homens(){
	$('#contatos .cabec3').each(function(index, element) {			
		 a=$(element).data("sexo");
		 b=$(element).attr("id"); 
		 if(a==2){$('#'+b).hide();} else {$('#'+b).show();}
	});			
}

function pesquisa_mulheres(){
	$('#contatos .cabec3').each(function(index, element) {			
		 a=$(element).data("sexo");
		 b=$(element).attr("id"); 
		 if(a==1){$('#'+b).hide();} else {$('#'+b).show();}
	});		
}

function inicar_whatsapp(){
    getUnico(function (itens) {	        	    
    	    var len = itens.length;
    	    if(len>0){
    	    	id_conversa=itens[0].IDCONVERSA;
    	    	id_data=itens[0].DATA;
    	    }  
			websocketiniciar();
			listarcontatos_locais();
			carregar_contatos_servidor();
			carregar_conversas_servidor();
         },'whatsappcontadores',id_usuario);
}

function mostrar_botoes(){
	if($('#barra_botoes').css('display')=='none'){$('#barra_botoes').show();}
	else {$('#barra_botoes').hide();}
}

