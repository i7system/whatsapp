
      
function websocketiniciar(){
    var socket = new SockJS('/ws');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, onConnected, onError);
}        
        
function onConnected() {
    stompClient.subscribe('/topic/public', onMessageReceived);
    stompClient.send("/app/chat.addUser",{},JSON.stringify({nome: nome_usuario,foto: foto_usuario,idusuario: id_usuario,latitude: latitude_usuario,longitude: longitude_usuario,sexo: sexo_usuario,frase: frase_usuario, type: 'JOIN'})
    )
}

function onError(error) {
	//alert('erro no websocket');
}

function onMessageReceived(payload) {
    var message = JSON.parse(payload.body);	
    
    if(message.type === 'CHAT') {
         inserirconversa(message.idmensagem,message.idusuario,message.iddestinatario,1,message.conteudo,message.data, message.nome, message.foto,message.idcontato,message.latitude,message.longitude,message.sexo,message.frase);       
    }
}
