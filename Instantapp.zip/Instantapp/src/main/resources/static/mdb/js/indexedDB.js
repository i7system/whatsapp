var indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB || window.shimIndexedDB;

var nome_banco="i7";
var versao_banco=1;

function matar_banco(){
	var req = indexedDB.deleteDatabase(nome_banco);
	req.onsuccess = function () {
	  abrir_banco();
};
}

function abrir_banco(){
	let openRequest = window.indexedDB.open(nome_banco, versao_banco);
	let DB;
	var criou='N';
	
	openRequest.onupgradeneeded = () => {  
		DB = openRequest.result;
		DB.createObjectStore('whatsappcontadores', {keyPath: 'IDUSUARIO'}); 		
		DB.createObjectStore("whatsappusuarios", { keyPath: "IDUSUARIO"});
	
		var tabelaconversa = DB.createObjectStore("whatsappconversas", { keyPath: "IDCONVERSA"});
		tabelaconversa.createIndex("IDCONTATO","IDCONTATO", { unique: false });
		
		crud(1,'whatsappcontadores',{IDUSUARIO:id_usuario, IDCONVERSA:0, DATA:"2000-01-01T00:00:00Z"},'');
		criou='S';  
	}
	
	openRequest.onsuccess = () => {
		DB = openRequest.result;
		DB.close();	
		if(criou=='N'){
			getUnico(function (itens) {
				var qtde = itens.length;
				if(qtde==0){
					matar_banco();
				} 
				else {
					inicar_whatsapp();
				}
			},'whatsappcontadores',id_usuario);	 		
		}
		
		if(criou=='S'){
			inicar_whatsapp();
		}
	}
	
	openRequest.onerror = () => {
		console.log("erro ao tentar conectar ao banco");
	}
}



function crud(acao,tabela,obj,js){
    
	let openRequest = window.indexedDB.open(nome_banco, versao_banco);
	let DB; 
	openRequest.onsuccess = () => {
	    //console.log("Conexão ao banco estabelecida com sucesso");
	        DB = openRequest.result;
	        
	        // incluir
	        if(acao==1){
	            let request = DB.transaction([tabela], "readwrite").objectStore(tabela).add(obj);
	            request.onsuccess = () => {if(js!=""){eval(js);}}
	            request.onerror = () => {console.log(request.error);}
	        }

	     // alterar
	        if(acao==2){
	            let request = DB.transaction([tabela], "readwrite").objectStore(tabela).put(obj);
	            request.onsuccess = () => {if(js!=""){eval(js);}}
	            request.onerror = () => {console.log(request.error);}
	        }
	        
	        // deletar
	        if(acao==3){
	            registro=obj.chave;
	            let request = DB.transaction([tabela], "readwrite").objectStore(tabela).delete(registro);
	            request.onsuccess = () => {if(js!=""){eval(js);}}
	            request.onerror = () => {console.log(request.error);}
	        }

	        //listar unico registro
	      //  if(acao==4){
	      //      registro=obj.chave;
	      //      let request = DB.transaction([tabela], "readwrite").objectStore(tabela).get(registro);
	      //      request.onsuccess = () => {console.log(request.result);if(js!=""){eval(js);}}
	      //      request.onerror = () => {console.log(request.error);}
	      //  }

	        //listar todos registros
	      //  if(acao==5){
	      //      let request = DB.transaction([tabela], "readwrite").objectStore(tabela).getAll();
	      //      request.onsuccess = () => {console.log(request.result);if(js!=""){eval(js);}}
	      //      request.onerror = () => {console.log(request.error);}
	      //  }
	        
	        // deletar todos os registros da tabela
	        if(acao==6){
	        	let request = DB.transaction([tabela], "readwrite").objectStore(tabela).clear();
	        }
	        
	    }    	    
	}   


// pegar todos os registros
function getAllDB(callback,tabela) {
	let openRequest = window.indexedDB.open(nome_banco, versao_banco);
	let DB; 

	openRequest.onsuccess = () => {
	DB = openRequest.result;
	        
    var trans = DB.transaction(tabela, IDBTransaction.READ_ONLY);
    var store = trans.objectStore(tabela);
    var itens = [];
 
    trans.oncomplete = function(evt) {  
        callback(itens);
    };
 
    var cursorRequest = store.openCursor();
 
    cursorRequest.onerror = function(error) {
        console.log(error);
    };
 
    cursorRequest.onsuccess = function(evt) {                    
        var cursor = evt.target.result;
        if (cursor) {
            itens.push(cursor.value);
            cursor.continue();
        }
    };
	}
}

//pegar apenas 1 registro
function getUnico(callback,tabela,chave) {
	
	
	//alert(tabela +'/'+chave);
	
	let openRequest = window.indexedDB.open(nome_banco, versao_banco);
	let DB; 

	openRequest.onsuccess = () => {
	DB = openRequest.result;
	        
    var trans = DB.transaction(tabela, IDBTransaction.READ_ONLY);
    var store = trans.objectStore(tabela);
    var itens = [];
 
    
    
//	var transaction = DB.transaction(tabela, "readonly");
//	var store = transaction.objectStore(tabela);
//	var index = store.index(nome_index);
	var filtro = IDBKeyRange.only(chave);	 
//	var cursorRequest = index.openCursor(filtro); 
    
    
    trans.oncomplete = function(evt) {  
        callback(itens);
    };
    
    var cursorRequest = store.openCursor(filtro);
 
    cursorRequest.onerror = function(error) {
        console.log(error);
    };
 
    cursorRequest.onsuccess = function(evt) {                    
        var cursor = evt.target.result;
        if (cursor) {
            itens.push(cursor.value);
            cursor.continue();
        }
    };
	}
}

//pegar todos os registros de um index
function getporindex(callback,tabela,nome_index,chave) {
	let openRequest = window.indexedDB.open(nome_banco, versao_banco);
	let DB; 
	var itens = [];
	
	openRequest.onsuccess = () => {
		DB = openRequest.result;
		
		var transaction = DB.transaction(tabela, "readonly");
		var store = transaction.objectStore(tabela);
		var index = store.index(nome_index);
		var filtro = IDBKeyRange.only(chave);	 
		var cursorRequest = index.openCursor(filtro);
				
		transaction.oncomplete = function(evt) {  
			callback(itens);
		};
		   
		cursorRequest.onsuccess = function(evt) {                    
			var cursor = evt.target.result;
			if (cursor) {
				itens.push(cursor.value);
				cursor.continue();
			}
		};
	}; 
}

abrir_banco();


