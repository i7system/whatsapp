package br.com.whatsapp.models;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "sec_usuarios", uniqueConstraints = {@UniqueConstraint(columnNames = {"email"})})

public class SecUsuarios {	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDUSUARIO", nullable = false)	
	private int IDUSUARIO;
	@Column(name = "TOKEN", length = 250,nullable = false)
	private String TOKEN;
	@Column(name = "NOME", length = 50,nullable = false)
	private String NOME;
	@Column(name = "FOTO", length = 250,nullable = false)
	private String FOTO;
	@Column(name = "EMAIL", length = 250,nullable = false)
	private String EMAIL;
	@Column(name = "SENHA", length = 250,nullable = false)
	private String SENHA;
	@Column(name = "SEXO",nullable = false)
	private int SEXO;
	@Column(name = "IDPAGINA",nullable = false)
	private int IDPAGINA;
	@Column(name = "IDCONVERSA",nullable = false)
	private int IDCONVERSA;
	@Column(name = "IDDEPARTAMENTO",nullable = false)
	private int IDDEPARTAMENTO;
	@Column(name = "CPF", length = 50,nullable = false)
	private String CPF;
	@Column(name = "CARGO", length = 50,nullable = false)
	private String CARGO;
	@Column(name = "DDI",nullable = false)
	private int DDI;	
	@Column(name = "DDD",nullable = false)
	private int DDD;	
	@Column(name = "TELEFONE", length = 30,nullable = false)
	private String TELEFONE;	
	@Column(name = "STATUS",nullable = false)
	private int STATUS;	
	@Column(name="LATITUDE", columnDefinition="Decimal(18,15) default '0.00'",precision=18, scale=15)
	private double  LATITUDE;	
	@Column(name="LONGITUDE", columnDefinition="Decimal(18,15) default '0.00'",precision=18, scale=15)
	private double  LONGITUDE;
	@Column(name = "FRASE", length = 2000,nullable = false)
	private String FRASE;		
	@Column(name = "IDIDIOMA",nullable = false)
    private int IDIDIOMA;
	@Column(name = "IDCIDADE",nullable = false)
    private int IDCIDADE;   
	
	
	@ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "sec_usuarios_perfis", joinColumns = @JoinColumn(name = "IDUSUARIO"), inverseJoinColumns = @JoinColumn(name = "IDPERFIL"))
    private Set<SecPerfis> roles;		  



	public SecUsuarios() {}    
	
    public int getIDCIDADE() {
		return IDCIDADE;
	}

	public void setIDCIDADE(int iDCIDADE) {
		IDCIDADE = iDCIDADE;
	}

	public Set<SecPerfis> getRoles() {
		return roles;
	}

	public void setRoles(Set<SecPerfis> roles) {
		this.roles = roles;
	}
    
	public int getIDUSUARIO() {
		return IDUSUARIO;
	}

	public void setIDUSUARIO(int iDUSUARIO) {
		IDUSUARIO = iDUSUARIO;
	}

	public String getNOME() {
		return NOME;
	}

	public void setNOME(String nOME) {
		NOME = nOME;
	}

	public String getFOTO() {
		return FOTO;
	}

	public void setFOTO(String fOTO) {
		FOTO = fOTO;
	}

	public String getEMAIL() {
		return EMAIL;
	}

	public void setEMAIL(String eMAIL) {
		EMAIL = eMAIL;
	}

	public String getSENHA() {
		return SENHA;
	}

	public void setSENHA(String sENHA) {
		SENHA = sENHA;
	}

	public int getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}

	public int getIDIDIOMA() {
		return IDIDIOMA;
	}

	public void setIDIDIOMA(int iDIDIOMA) {
		IDIDIOMA = iDIDIOMA;
	}

	public String getTOKEN() {
		return TOKEN;
	}

	public void setTOKEN(String tOKEN) {
		TOKEN = tOKEN;
	}

	public int getSEXO() {
		return SEXO;
	}

	public void setSEXO(int sEXO) {
		SEXO = sEXO;
	}

	public int getIDCONVERSA() {
		return IDCONVERSA;
	}

	public void setIDCONVERSA(int iDCONVERSA) {
		IDCONVERSA = iDCONVERSA;
	}

	public double  getLATITUDE() {
		return LATITUDE;
	}

	public void setLATITUDE(double  lATITUDE) {
		LATITUDE = lATITUDE;
	}

	public double getLONGITUDE() {
		return LONGITUDE;
	}

	public void setLONGITUDE(double lONGITUDE) {
		LONGITUDE = lONGITUDE;
	}

	public String getFRASE() {
		return FRASE;
	}

	public void setFRASE(String fRASE) {
		FRASE = fRASE;
	}

	public int getIDPAGINA() {
		return IDPAGINA;
	}

	public void setIDPAGINA(int iDPAGINA) {
		IDPAGINA = iDPAGINA;
	}

	public String getCPF() {
		return CPF;
	}

	public void setCPF(String cPF) {
		CPF = cPF;
	}

	public int getIDDEPARTAMENTO() {
		return IDDEPARTAMENTO;
	}

	public void setIDDEPARTAMENTO(int iDDEPARTAMENTO) {
		IDDEPARTAMENTO = iDDEPARTAMENTO;
	}

	public String getCARGO() {
		return CARGO;
	}

	public void setCARGO(String cARGO) {
		CARGO = cARGO;
	}

	public int getDDI() {
		return DDI;
	}

	public void setDDI(int dDI) {
		DDI = dDI;
	}

	public int getDDD() {
		return DDD;
	}

	public void setDDD(int dDD) {
		DDD = dDD;
	}

	public String getTELEFONE() {
		return TELEFONE;
	}

	public void setTELEFONE(String tELEFONE) {
		TELEFONE = tELEFONE;
	}
	
}
