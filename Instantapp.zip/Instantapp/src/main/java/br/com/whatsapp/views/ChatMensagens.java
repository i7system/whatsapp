package br.com.whatsapp.views;

import java.time.Instant;

public class ChatMensagens {
    private MessageType type;
    private String conteudo;
    private int idusuario;
    private String foto;
    private String nome;
    private int iddestinatario;
    private Instant data;
    private int idmensagem;
    private int idcontato;
    private String latitude;
    private String longitude;
    private int sexo;
    private String frase;

	public enum MessageType {
        CHAT,
        JOIN,
        LEAVE
    }
	
	public int getIdmensagem() {
		return idmensagem;
	}

	public void setIdmensagem(int idmensagem) {
		this.idmensagem = idmensagem;
	}

	public Instant getData() {
		return data;
	}

	public void setData(Instant data) {
		this.data = data;
	}

	public MessageType getType() {
		return type;
	}

	public void setType(MessageType type) {
		this.type = type;
	}

	public String getConteudo() {
		return conteudo;
	}

	public void setConteudo(String conteudo) {
		this.conteudo = conteudo;
	}

	public int getIdusuario() {
		return idusuario;
	}

	public void setIdusuario(int idusuario) {
		this.idusuario = idusuario;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIddestinatario() {
		return iddestinatario;
	}

	public void setIddestinatario(int iddestinatario) {
		this.iddestinatario = iddestinatario;
	}
   
	public int getIdcontato() {
		return idcontato;
	}

	public void setIdcontato(int idcontato) {
		this.idcontato = idcontato;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public int getSexo() {
		return sexo;
	}

	public void setSexo(int sexo) {
		this.sexo = sexo;
	}

	public String getFrase() {
		return frase;
	}

	public void setFrase(String frase) {
		this.frase = frase;
	}	
	
}
