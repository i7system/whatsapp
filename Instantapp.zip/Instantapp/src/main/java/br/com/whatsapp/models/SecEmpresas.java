package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "sec_empresas")
public class SecEmpresas {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDEMPRESA", nullable = false)
	private int IDEMPRESA;
	@Column(name = "NOME", length = 50,nullable = false)
	private String NOME;
	@Column(name = "NOMEFANTASIA", length = 50,nullable = false)
	private String NOMEFANTASIA; 
	@Column(name = "LOGO", length = 250,nullable = false)	
	private String LOGO;	
	@Column(name = "ICONE", length = 250,nullable = false)
	private String ICONE;
	@Column(name = "SLOGAN", length = 250,nullable = false)
	private String SLOGAN; 
	@Column(name = "STATUS",nullable = false)
	private int STATUS;	
	
    public SecEmpresas() {}

	public int getIDEMPRESA() {
		return IDEMPRESA;
	}

	public void setIDEMPRESA(int iDEMPRESA) {
		IDEMPRESA = iDEMPRESA;
	}

	public String getNOME() {
		return NOME;
	}

	public void setNOME(String nOME) {
		NOME = nOME;
	}

	public String getNOMEFANTASIA() {
		return NOMEFANTASIA;
	}

	public void setNOMEFANTASIA(String nOMEFANTASIA) {
		NOMEFANTASIA = nOMEFANTASIA;
	}

	public String getLOGO() {
		return LOGO;
	}

	public void setLOGO(String lOGO) {
		LOGO = lOGO;
	}

	public String getICONE() {
		return ICONE;
	}

	public void setICONE(String iCONE) {
		ICONE = iCONE;
	}

	public String getSLOGAN() {
		return SLOGAN;
	}

	public void setSLOGAN(String sLOGAN) {
		SLOGAN = sLOGAN;
	}

	public int getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}
	
}
