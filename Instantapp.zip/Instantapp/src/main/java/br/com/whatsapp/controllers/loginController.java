package br.com.whatsapp.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.whatsapp.models.SecUsuarios;
import br.com.whatsapp.services.sec_empresasService;
import br.com.whatsapp.services.sec_usuariosService;


@Controller
@Transactional
public class loginController {
	
	@Autowired
	private sec_usuariosService service01; 
	
//	@Autowired
//	private sec_empresasService service02;			
	
	@RequestMapping(value={"/teste"}, method = RequestMethod.GET)
    public ModelAndView teste(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("teste");
        return modelAndView;
    }          
 
	@RequestMapping(value={"/websocket"}, method = RequestMethod.GET)
    public ModelAndView websocket(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("websocket");
        return modelAndView;
    }          
 		
   @RequestMapping(value={"/login"}, method = RequestMethod.GET)
   public ModelAndView login(){
       ModelAndView modelAndView = new ModelAndView();
      // modelAndView.addObject("sec_empresas", service02.findsec_empresasByIDEMPRESA(1));
       modelAndView.setViewName("login");
       return modelAndView;
   }
   
    @RequestMapping(value={"/alterarsenha"}, method = RequestMethod.GET)
    public ModelAndView alterarsenha(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("alterarsenha");
        return modelAndView;
    }  
    
    @RequestMapping(value={"/financeiro"}, method = RequestMethod.GET)
    public ModelAndView financeiro(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("financeiro");
        return modelAndView;
    }
    
    @RequestMapping(value={"/meuscertificados"}, method = RequestMethod.GET)
    public ModelAndView meuscertificados(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("meuscertificados");
        return modelAndView;
    }    
      
    @RequestMapping(value="/registro", method = RequestMethod.GET)
    public ModelAndView registro(){
        ModelAndView modelAndView = new ModelAndView();
        SecUsuarios sec_usuarios = new SecUsuarios();
        modelAndView.addObject("sec_usuarios", sec_usuarios);
        modelAndView.setViewName("registro");
        return modelAndView;
    }
    
    @RequestMapping(value = "/registrogravar", method = RequestMethod.POST)
    public ModelAndView registrogravar(@Valid SecUsuarios sec_usuarios, BindingResult bindingResult) {
        ModelAndView modelAndView = new ModelAndView();
        SecUsuarios userExists = service01.findsec_usuariosByEMAIL(sec_usuarios.getEMAIL());
        if (userExists != null) {
            bindingResult
                    .rejectValue("EMAIL", "error.user",
                            "There is already a user registered with the email provided");
        }
        if (bindingResult.hasErrors()) {
            modelAndView.setViewName("registro");
        } else {
        	
        	service01.savesec_usuarios(sec_usuarios);
            modelAndView.addObject("successMessage", "User has been registered successfully");
            modelAndView.addObject("sec_usuarios", new SecUsuarios());
            modelAndView.setViewName("login");

        }
        return modelAndView;
    }  
}