package br.com.whatsapp.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class autologin
{

    //@Autowired
   // RequestCache requestCache;

   // @Autowired
   // protected AuthenticationManager authenticationManager;

      
    
  //  @RequestMapping(value = "/banana", method = RequestMethod.POST)
  //  public String createNewUser(@RequestParam("txtEmail") String email,@RequestParam("txtSenha") String senha, BindingResult result,  HttpServletRequest request, HttpServletResponse response) {
     
    	
   // 	System.out.println("email:"+email);
   // 	System.out.println("senha:"+senha);
    	
    	
    	//authenticateUserAndSetSession(email,senha, request, response);
   //     return "redirect:/home/";
  //  }

    
    
    
   // private void authenticateUserAndSetSession(String email,String senha, HttpServletRequest request,HttpServletResponse response) {

   //     UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(email, senha);
        
   //     System.out.println("token:"+token);
        

        // generate session if one doesn't exist
   //     request.getSession();

   //     token.setDetails(new WebAuthenticationDetails(request));
   //     Authentication authenticatedUser = authenticationManager.authenticate(token);

   //     SecurityContextHolder.getContext().setAuthentication(authenticatedUser);
   // }
}
