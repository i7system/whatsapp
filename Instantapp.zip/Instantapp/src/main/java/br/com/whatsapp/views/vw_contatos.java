package br.com.whatsapp.views;

public class vw_contatos {

	private int IDCONTATO;
	private int IDUSUARIO; 
	private int IDUSUARIOCONTATO;
	private String DATA;
	private String MENSAGEM;
	private int QTDE;
	private String NOME;
	private String FOTO;
	private String LONGITUDE;
	private String LATITUDE;
	private int SEXO;
	private String FRASE;
	
	public vw_contatos() {
		// TODO Auto-generated constructor stub
	}
	
	public int getIDCONTATO() {
		return IDCONTATO;
	}
	public void setIDCONTATO(int iDCONTATO) {
		IDCONTATO = iDCONTATO;
	}
	public int getIDUSUARIO() {
		return IDUSUARIO;
	}
	public void setIDUSUARIO(int iDUSUARIO) {
		IDUSUARIO = iDUSUARIO;
	}
	public int getIDUSUARIOCONTATO() {
		return IDUSUARIOCONTATO;
	}
	public void setIDUSUARIOCONTATO(int iDUSUARIOCONTATO) {
		IDUSUARIOCONTATO = iDUSUARIOCONTATO;
	}
	public String getDATA() {
		return DATA;
	}
	public void setDATA(String dATA) {
		DATA = dATA;
	}
	public String getMENSAGEM() {
		return MENSAGEM;
	}
	public void setMENSAGEM(String mENSAGEM) {
		MENSAGEM = mENSAGEM;
	}
	public int getQTDE() {
		return QTDE;
	}
	public void setQTDE(int qTDE) {
		QTDE = qTDE;
	}
	public String getNOME() {
		return NOME;
	}
	public void setNOME(String nOME) {
		NOME = nOME;
	}
	public String getFOTO() {
		return FOTO;
	}
	public void setFOTO(String fOTO) {
		FOTO = fOTO;
	}

	public String getLONGITUDE() {
		return LONGITUDE;
	}

	public void setLONGITUDE(String lONGITUDE) {
		LONGITUDE = lONGITUDE;
	}

	public String getLATITUDE() {
		return LATITUDE;
	}

	public void setLATITUDE(String lATITUDE) {
		LATITUDE = lATITUDE;
	}

	public int getSEXO() {
		return SEXO;
	}

	public void setSEXO(int sEXO) {
		SEXO = sEXO;
	}

	public String getFRASE() {
		return FRASE;
	}

	public void setFRASE(String fRASE) {
		FRASE = fRASE;
	}	
	
}
