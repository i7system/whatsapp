
package br.com.whatsapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import br.com.whatsapp.repository.zap_conversasRepository;
import br.com.whatsapp.models.ZapConversas;

@RestController
public class zap_conversasController {
	
   @Autowired
   private zap_conversasRepository repositorio01;

    @RequestMapping(value = "/listarconversas", method = RequestMethod.GET)
    @ResponseBody
	public List<ZapConversas> listarconversasporusuario(@RequestParam("idconversa") int idconversa,@RequestParam("idusuario") int idusuario) {
	    return repositorio01.ListarConversas(idconversa,idusuario,idusuario);
	} 
	
}
