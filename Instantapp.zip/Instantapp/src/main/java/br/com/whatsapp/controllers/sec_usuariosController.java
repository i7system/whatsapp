package br.com.whatsapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import br.com.whatsapp.services.sec_usuariosService;
import br.com.whatsapp.views.vw_coordenadas;

@Controller
public class sec_usuariosController {
	

	@Autowired
	private sec_usuariosService service01; 
	
	
    @RequestMapping(value = "/gravarcoordenadas", method = RequestMethod.GET)
    public vw_coordenadas gravarcoordenadas(vw_coordenadas coordenadas) {  
    	    System.out.println("11111111111111111111111111111111111111111111111");
    	    System.out.println(coordenadas.getLATITUDE()+"/"+coordenadas.getLONGITUDE());
    	    System.out.println("11111111111111111111111111111111111111111111111");
        	service01.atualizarcoordenadas(coordenadas.getLATITUDE(), coordenadas.getLONGITUDE());
    	    System.out.println("2222222222222222222222222222222222222");
    	    return coordenadas;

     }


	//@RequestMapping(value="/gravarcoordenadas",method=RequestMethod.GET,produces="application/json", consumes = "application/json")
    //public void gravarcoordenadas(@RequestBody SecUsuarios usuario){
         
        //ObjectMapper mapper = new ObjectMapper();
        //Map<String, Object> map = mapper.readValue(json,Person.class);
         
      //  System.out.println(usuario.getLATITUDE()+"/"+ usuario.getLONGITUDE());
    	
         
        
        
   // }


}
