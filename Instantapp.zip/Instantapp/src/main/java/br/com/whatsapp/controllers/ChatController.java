package br.com.whatsapp.controllers;

import br.com.whatsapp.views.ChatMensagens;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;
import br.com.whatsapp.services.zap_conversasService;

@Controller
public class ChatController {

	@Autowired
	private zap_conversasService servico01; 
	
    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMensagens sendMessage(@Payload ChatMensagens mensagem) {
         servico01.savezap_conversas(mensagem);
        return mensagem;
    }

    @MessageMapping("/chat.addUser")
    @SendTo("/topic/public")
    public ChatMensagens addUser(@Payload ChatMensagens chatMensagens, SimpMessageHeaderAccessor headerAccessor) {
        // Add username in web socket session   	
        headerAccessor.getSessionAttributes().put("IDUSUARIO", chatMensagens.getIdusuario());
        headerAccessor.getSessionAttributes().put("NOME", chatMensagens.getNome());
        headerAccessor.getSessionAttributes().put("FOTO", chatMensagens.getFoto());
        headerAccessor.getSessionAttributes().put("LATITUDE", chatMensagens.getLatitude());
        headerAccessor.getSessionAttributes().put("LONGITUDE", chatMensagens.getLongitude());
        headerAccessor.getSessionAttributes().put("SEXO", chatMensagens.getSexo());
        headerAccessor.getSessionAttributes().put("FRASE", chatMensagens.getFrase());
        return chatMensagens;
    }

}
