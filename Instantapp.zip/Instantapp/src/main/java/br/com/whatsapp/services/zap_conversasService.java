package br.com.whatsapp.services;

import br.com.whatsapp.models.SecUsuarios;
import br.com.whatsapp.models.ZapConversas;
import br.com.whatsapp.repository.sec_usuariosRepository;
import br.com.whatsapp.repository.zap_conversasRepository;
import br.com.whatsapp.views.ChatMensagens;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class zap_conversasService  {

	@Autowired
	private zap_conversasRepository repositorio01;
	
	@Autowired
	private sec_usuariosRepository repositorio02;

    public void savezap_conversas(ChatMensagens mensagem) {   	
    	
    	ZapConversas conversa = new ZapConversas();   
    	SecUsuarios contador1 = new SecUsuarios();   
    	SecUsuarios contador2 = new SecUsuarios();      	
    	
        conversa.setIDCONVERSA(0);
    	conversa.setDATA(mensagem.getData());
    	conversa.setMENSAGEM(mensagem.getConteudo());
    	conversa.setSTATUS(1);
    	conversa.setIDUSUARIO(mensagem.getIdusuario());
    	conversa.setIDUSUARIODESTINATARIO(mensagem.getIddestinatario());
    	conversa.setIDTIPOCONVERSA(1);
    	repositorio01.save(conversa);
    	mensagem.setIdmensagem(conversa.getIDCONVERSA());
    	
       	contador1=repositorio02.findByIDUSUARIO(conversa.getIDUSUARIO());
    	contador1.setIDCONVERSA(conversa.getIDCONVERSA());
    	repositorio02.save(contador1);
  
     	contador2=repositorio02.findByIDUSUARIO(conversa.getIDUSUARIODESTINATARIO());     	
    	contador2.setIDCONVERSA(conversa.getIDCONVERSA());
    	repositorio02.save(contador2);
    	
     }  
    
//	public void deletesec_usuarios(int idusuario) { 
//		repositorio01.deleteById(idusuario);
//	}   
    
//	public List lista(int IDUSUARIO) {			
//		Pageable paginacao = PageRequest.of(0, 1000000, Sort.by("NOME").ascending());
//		return repositorio01.resultado(paginacao,IDUSUARIO);		
//	}
	
}


