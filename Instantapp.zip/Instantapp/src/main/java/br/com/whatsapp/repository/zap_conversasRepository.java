package br.com.whatsapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import br.com.whatsapp.models.ZapConversas;

@Repository
public interface zap_conversasRepository extends JpaRepository<ZapConversas, Integer>{
	

//@Query(value = "SELECT a.IDCONTATO, a.IDUSUARIO, a.IDUSUARIOCONTATO, a.DATA, a.MENSAGEM, a.QTDE,b.NOME,b.FOTO " + 
//		        " FROM zap_contatos a,sec_usuarios b " + 
//		        " WHERE a.IDUSUARIOCONTATO=b.IDUSUARIO AND a.IDUSUARIO=1 ", nativeQuery = true)
//public List listarcontatos();


//@Query(value = "SELECT a.IDCONVERSA, a.DATA, a.MENSAGEM, a.STATUS, a.IDUSUARIO, a.IDUSUARIODESTINATARIO, a.IDTIPOCONVERSA " + 
//		       " FROM zap_conversas a WHERE a.IDCONVERSA>?1 AND (a.IDUSUARIO=?2 OR a.IDUSUARIODESTINATARIO=?3) ORDER BY IDCONVERSA  ", nativeQuery = true)
//public List listarconversasporusuario(int idconversa,int idusuario,int idusuariodestinatario);


@Query("SELECT u FROM ZapConversas u  WHERE u.IDCONVERSA>?1 AND (u.IDUSUARIO=?2 OR u.IDUSUARIODESTINATARIO=?3) ORDER BY u.IDCONVERSA")
public List ListarConversas(int idconversa,int idusuario,int idusuariodestinatario);


}
