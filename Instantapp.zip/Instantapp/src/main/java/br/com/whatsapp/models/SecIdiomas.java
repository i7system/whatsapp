package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "sec_idiomas")
public class SecIdiomas {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDIDIOMA", nullable = false)
	private int IDIDIOMA;
	@Column(name = "NOME", length = 50,nullable = false)	
	private String NOME; 
	@Column(name = "STATUS", nullable = false)	
	private int STATUS;
	
    public SecIdiomas() {}
	
	public int getIDIDIOMA() {
		return IDIDIOMA;
	}
	public void setIDIDIOMA(int iDIDIOMA) {
		IDIDIOMA = iDIDIOMA;
	}
	public String getNOME() {
		return NOME;
	}
	public void setNOME(String nOME) {
		NOME = nOME;
	}
	public int getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}
	

	
}
