
package br.com.whatsapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@Transactional
public class FotosController {
	
	@Autowired
	private DiscoController disco;
	
	@RequestMapping(value={"/fotosupload"}, method = RequestMethod.POST)
    public void fotosupload(@RequestParam("upload_foto") MultipartFile foto){
  	  disco.salvarFoto(foto);
    }		

}
