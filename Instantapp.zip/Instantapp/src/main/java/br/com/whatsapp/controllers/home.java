package br.com.whatsapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.whatsapp.services.sec_empresasService;
import br.com.whatsapp.services.sec_usuariosService;

@RestController
@Transactional
public class home {
	
	@Autowired
	private sec_usuariosService service01; 
	
	@Autowired
	private sec_empresasService service02;	

    @RequestMapping(value={"/home"}, method = RequestMethod.GET)
    public ModelAndView home(){
        ModelAndView modelAndView = new ModelAndView();      
        modelAndView.addObject("sec_usuarios", service01.registro());
        modelAndView.addObject("sec_empresas", service02.findsec_empresasByIDEMPRESA(1));     
        modelAndView.setViewName("home");
        return modelAndView;
    }
    
    @RequestMapping(value={"/alterardadospessoais"}, method = RequestMethod.GET)
    public ModelAndView alterardadospessoais(){
        ModelAndView modelAndView = new ModelAndView();      
        modelAndView.addObject("sec_usuarios", service01.registro());
    //    modelAndView.addObject("sec_empresas", service02.findsec_empresasByIDEMPRESA(1));     
        modelAndView.setViewName("alterardadospessoais");
        return modelAndView;
    } 
       
	@RequestMapping(value={"/maps"}, method = RequestMethod.GET)
    public ModelAndView maps(){
        ModelAndView modelAndView = new ModelAndView();  
        modelAndView.setViewName("maps");
        return modelAndView;
    }     
	
	@RequestMapping(value={"/","/index"}, method = RequestMethod.GET)
    public ModelAndView index(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index");
        return modelAndView;
    }   

	@RequestMapping(value={"/index01"}, method = RequestMethod.GET)
    public ModelAndView index01(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index01");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index02"}, method = RequestMethod.GET)
    public ModelAndView index02(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index02");
        return modelAndView;
    }  
	
	@RequestMapping(value={"/index03"}, method = RequestMethod.GET)
    public ModelAndView index03(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index03");
        return modelAndView;
    }  
	
	@RequestMapping(value={"/index04"}, method = RequestMethod.GET)
    public ModelAndView index04(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index04");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index05"}, method = RequestMethod.GET)
    public ModelAndView index05(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index05");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index06"}, method = RequestMethod.GET)
    public ModelAndView index06(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index06");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index07"}, method = RequestMethod.GET)
    public ModelAndView index07(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index07");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index08"}, method = RequestMethod.GET)
    public ModelAndView index08(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index08");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index09"}, method = RequestMethod.GET)
    public ModelAndView index09(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index09");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/index10"}, method = RequestMethod.GET)
    public ModelAndView index10(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index10");
        return modelAndView;
    }   
	
	@RequestMapping(value={"/emulador"}, method = RequestMethod.GET)
    public ModelAndView emulador(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("emulador");
        return modelAndView;
    }   

	@RequestMapping(value={"/emulador2"}, method = RequestMethod.GET)
    public ModelAndView emulador2(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("emulador2");
        return modelAndView;
    }   	
	
}
