package br.com.whatsapp.repository;

import java.time.Instant;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import br.com.whatsapp.models.ZapContatos;

@Repository
public interface vw_contatosRepository extends JpaRepository<ZapContatos, Integer>{
	
@Query(value = "SELECT a.IDCONTATO, a.IDUSUARIO, a.IDUSUARIOCONTATO, a.DATA, a.MENSAGEM, a.QTDE,b.NOME,b.FOTO,b.LATITUDE,b.LONGITUDE,b.FRASE,b.SEXO " + 
        " FROM zap_contatos a,sec_usuarios b " + 
        " WHERE a.IDUSUARIOCONTATO=b.IDUSUARIO AND a.IDUSUARIO=? ORDER BY a.DATA DESC", nativeQuery = true)
public List listarcontatosporusuario(int idusuario);

@Query(value = "SELECT a.IDCONTATO, a.IDUSUARIO, a.IDUSUARIOCONTATO, a.DATA, a.MENSAGEM, a.QTDE,b.NOME,b.FOTO,b.LATITUDE,b.LONGITUDE,b.FRASE,b.SEXO  " + 
        " FROM zap_contatos a,sec_usuarios b " + 
        " WHERE a.IDUSUARIOCONTATO=b.IDUSUARIO AND a.IDUSUARIO=?1 AND a.DATA>?2 ORDER BY a.DATA DESC ", nativeQuery = true)
public List listarcontatospordata(int idusuario,Instant data);

@Query(value = "SELECT b.IDUSUARIO,b.NOME,b.FOTO,b.SEXO,b.FRASE,b.LATITUDE,b.LONGITUDE FROM sec_usuarios b WHERE b.IDUSUARIO<>? ORDER BY b.IDUSUARIO LIMIT 0,30", nativeQuery = true)
public List listarcontatosempresa1(int IDUSUARIO);

@Query(value = "SELECT b.IDUSUARIO,b.NOME,b.FOTO,b.SEXO,b.FRASE,b.LATITUDE,b.LONGITUDE FROM sec_usuarios b WHERE b.IDUSUARIO<>? ORDER BY b.NOME LIMIT 30,999999", nativeQuery = true)
public List listarcontatosempresa2(int IDUSUARIO);

@Query(value = "SELECT b.IDUSUARIO,b.NOME,b.FOTO,b.SEXO,b.FRASE,b.LATITUDE,b.LONGITUDE FROM sec_usuarios b ORDER BY b.NOME ", nativeQuery = true)
public List listarcontatosempresa3();

}