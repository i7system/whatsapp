package br.com.whatsapp;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatsappmobileApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatsappmobileApplication.class, args);
		System.out.println("Sistema iniciado");
	}
}

