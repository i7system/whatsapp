
package br.com.whatsapp.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import br.com.whatsapp.models.SecEmpresas;

@Repository
public interface sec_empresasRepository extends PagingAndSortingRepository<SecEmpresas, Integer> {		
	  SecEmpresas findByIDEMPRESA(int IDEMPRESA);	
	  @Query("select u from SecEmpresas u where u.STATUS = 1 ")
	  List<SecEmpresas> resultado(Pageable paginacao);	 
	  @Query("select u from SecEmpresas u ")
	  List<SecEmpresas> resultadocompleto(Pageable paginacao);	
}