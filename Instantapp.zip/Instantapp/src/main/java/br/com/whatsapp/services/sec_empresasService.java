


package br.com.whatsapp.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import br.com.whatsapp.models.SecEmpresas;
import br.com.whatsapp.repository.sec_empresasRepository;

@Service
public class sec_empresasService {
	
	@Autowired
	private sec_empresasRepository repositorio;

    public SecEmpresas findsec_empresasByIDEMPRESA(int IDEMPRESA) {
        return repositorio.findByIDEMPRESA(IDEMPRESA);
   }    
    
    public void savesec_empresas(SecEmpresas sec_empresas) {
    	repositorio.save(sec_empresas);
    }
	public void deletesec_empresas(int idempresa) { 
	   	repositorio.deleteById(idempresa);
	} 
    
	public List listacompleta(int pagina) {			
		Pageable paginacao = PageRequest.of(pagina, 3, Sort.by("NOME").ascending());
		return repositorio.resultadocompleto(paginacao);		
	}	

    public Page<SecEmpresas> listacompleta2(int pagina) {
    	Page<SecEmpresas> page = null;
        PageRequest pageRequest = PageRequest.of(pagina-1, 5,  Sort.Direction.ASC,  "NOME");
         page = repositorio.findAll(pageRequest);     
        return page;
    }
}
