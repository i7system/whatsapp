package br.com.whatsapp.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import br.com.whatsapp.models.SecUsuarios;

@Repository("sec_usuariosRepository")
public interface sec_usuariosRepository extends JpaRepository<SecUsuarios, Integer> {
	
	SecUsuarios findByEMAIL(String EMAIL);
	SecUsuarios findByIDUSUARIO(int IDUSUARIO);
	
	@Query("select u from SecUsuarios u where u.STATUS = 1 ")
	List<SecUsuarios> resultado(Pageable paginacao); 
	@Query("select u from SecUsuarios u ")
	List<SecUsuarios> resultadocompleto(Pageable paginacao);	

//	@Override
//	public List<sec_usuarios> findAll();
}