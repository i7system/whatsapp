
package br.com.whatsapp.repository;

import java.time.Instant;
import java.util.List;

import javax.persistence.EntityTransaction;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import br.com.whatsapp.models.ZapContatos;

@Repository
public interface zap_contatosRepository extends JpaRepository<ZapContatos, Integer>{
	
@Query("SELECT u FROM ZapContatos u WHERE u.IDUSUARIO=?1 ORDER BY u.DATA DESC")
public List ListarConversas(int idusuario);

@Modifying(clearAutomatically = true)
@Transactional
@Query("UPDATE ZapContatos u SET u.QTDE=u.QTDE+1,DATA=?3,MENSAGEM=?4 WHERE u.IDUSUARIO=?2 AND u.IDUSUARIOCONTATO=?1")
public void somarqtdecontato(int IDUSUARIO,int IDUSUARIOCONTATO,Instant DATA,String ULTIMA);

@Modifying(clearAutomatically = true)
@Transactional
@Query("UPDATE ZapContatos u SET u.QTDE=0,DATA=?3,MENSAGEM=?4 WHERE u.IDUSUARIO=?1 AND u.IDUSUARIOCONTATO=?2")
public void atualizarconversa(int IDUSUARIO,int IDUSUARIOCONTATO,Instant DATA,String ULTIMA);


}
