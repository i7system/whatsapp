package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "sec_usuarios_perfis")
public class SecUsuariosPerfis {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDUSUARIOPERFIL", nullable = false)	
	private int IDUSUARIOPERFIL; 
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "IDUSUARIO", nullable = false)
	private SecUsuarios secusuarios;	

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "IDPERFIL", nullable = false)
	private SecPerfis secperfis;

	public SecUsuariosPerfis() {}		
	
	public int getIDUSUARIOPERFIL() {
		return IDUSUARIOPERFIL;
	}

	public void setIDUSUARIOPERFIL(int iDUSUARIOPERFIL) {
		IDUSUARIOPERFIL = iDUSUARIOPERFIL;
	}

	public SecUsuarios getSecusuarios() {
		return secusuarios;
	}

	public void setSecusuarios(SecUsuarios secusuarios) {
		this.secusuarios = secusuarios;
	}

	public SecPerfis getSecperfis() {
		return secperfis;
	}

	public void setSecperfis(SecPerfis secperfis) {
		this.secperfis = secperfis;
	}	
	
}
