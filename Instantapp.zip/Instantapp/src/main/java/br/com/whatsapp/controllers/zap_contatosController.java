
package br.com.whatsapp.controllers;

import java.time.Instant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import br.com.whatsapp.models.ZapContatos;
import br.com.whatsapp.services.zap_contatosService;

@RestController
public class zap_contatosController {
	
	@Autowired
	private zap_contatosService service01; 
	
	
    @RequestMapping(value = "/somarqtdecontato", method = RequestMethod.GET)
    public void somarqtdecontato(int IDUSUARIO, int IDUSUARIOCONTATO,Instant DATA,String ULTIMA) {  	
         service01.somarqtdecontato(IDUSUARIO,IDUSUARIOCONTATO,DATA,ULTIMA);
     }	
	
    @RequestMapping(value = "/gravarcontato", method = RequestMethod.GET)
    public ZapContatos gravarcontato(ZapContatos contato) {  
         	return service01.savezap_contatos(contato);
     }
	
}
