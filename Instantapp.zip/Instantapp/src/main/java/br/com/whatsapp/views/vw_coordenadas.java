package br.com.whatsapp.views;

public class vw_coordenadas {
	
	private float LATITUDE;
	private float LONGITUDE;
	public float getLATITUDE() {
		return LATITUDE;
	}
	public void setLATITUDE(float lATITUDE) {
		LATITUDE = lATITUDE;
	}
	public float getLONGITUDE() {
		return LONGITUDE;
	}
	public void setLONGITUDE(float lONGITUDE) {
		LONGITUDE = lONGITUDE;
	}

	
	
}
