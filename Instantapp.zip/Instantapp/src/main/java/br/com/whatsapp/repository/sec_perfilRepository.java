package br.com.whatsapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.whatsapp.models.SecPerfis;

@Repository
public interface sec_perfilRepository extends JpaRepository<SecPerfis, Integer> { 	
	SecPerfis findByIDPERFIL(int IDPERFIL);	
	SecPerfis findByNOME(String NOME);
	  //@Query("select u from sec_empresas u where u.STATUS = 1 ")
	  //List<sec_empresas> resultado(Pageable paginacao);	 
	  //@Query("select u from sec_empresas u ")
	  //List<sec_empresas> resultadocompleto(Pageable paginacao);		
}