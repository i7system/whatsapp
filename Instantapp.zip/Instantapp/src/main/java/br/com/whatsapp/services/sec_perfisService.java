package br.com.whatsapp.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import br.com.whatsapp.models.SecPerfis;
import br.com.whatsapp.repository.sec_perfilRepository;;

@Service
public class sec_perfisService {

			@Autowired
			private sec_perfilRepository repositorio;
			
			public SecPerfis findsec_perfisByIDPERFIL(int IDPERFIL) {
			    return repositorio.findByIDPERFIL(IDPERFIL);
			} 
			
			public void savesec_perfis(SecPerfis sec_perfis) { 
			   	repositorio.save(sec_perfis);
			}        
			
			public void deletesec_perfis(int idperfil) { 
			   	repositorio.deleteById(idperfil);
			}  			
		
			public Page<SecPerfis> listacompleta2(int pagina) {
				Page<SecPerfis> page = null;
			    PageRequest pageRequest = PageRequest.of(pagina-1, 5,  Sort.Direction.ASC,  "NOME");
			     page = repositorio.findAll(pageRequest);     
			    return page;
			}
			
			}