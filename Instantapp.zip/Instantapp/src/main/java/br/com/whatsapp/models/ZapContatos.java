package br.com.whatsapp.models;

import java.time.Instant;
import javax.persistence.*;

@Entity
@Table(name = "zap_contatos")
	public class ZapContatos {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDCONTATO", nullable = false)
	private int IDCONTATO;	
	@Column(name = "IDUSUARIO", nullable = false)
	private int IDUSUARIO;
	@Column(name = "IDUSUARIOCONTATO", nullable = false)
	private int IDUSUARIOCONTATO;	
	@Column(name = "DATA", nullable = false)	
	private Instant DATA;
	@Column(name = "MENSAGEM", length = 250,nullable = false)
	private String MENSAGEM;
	@Column(name = "QTDE", nullable = false)
	private int QTDE;
	
	public int getIDCONTATO() {
		return IDCONTATO;
	}
	public void setIDCONTATO(int iDCONTATO) {
		IDCONTATO = iDCONTATO;
	}
	public int getIDUSUARIO() {
		return IDUSUARIO;
	}
	public void setIDUSUARIO(int iDUSUARIO) {
		IDUSUARIO = iDUSUARIO;
	}
	public int getIDUSUARIOCONTATO() {
		return IDUSUARIOCONTATO;
	}
	public void setIDUSUARIOCONTATO(int iDUSUARIOCONTATO) {
		IDUSUARIOCONTATO = iDUSUARIOCONTATO;
	}
	public Instant getDATA() {
		return DATA;
	}
	public void setDATA(Instant dATA) {
		DATA = dATA;
	}
	public String getMENSAGEM() {
		return MENSAGEM;
	}
	public void setMENSAGEM(String mENSAGEM) {
		MENSAGEM = mENSAGEM;
	}
	public int getQTDE() {
		return QTDE;
	}
	public void setQTDE(int qTDE) {
		QTDE = qTDE;
	}	
	
}
