package br.com.whatsapp.services;

import br.com.whatsapp.models.ZapContatos;
import br.com.whatsapp.repository.zap_contatosRepository;
import java.time.Instant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class zap_contatosService  {

	@Autowired
	private zap_contatosRepository repositorio01;

    public ZapContatos savezap_contatos(ZapContatos contato) {   	
    	repositorio01.save(contato);
    	return contato;
     }   	
    
    public void somarqtdecontato(int IDUSUARIO,int IDUSUARIOCONTATO,Instant DATA,String ULTIMA) { 
    	repositorio01.somarqtdecontato(IDUSUARIO,IDUSUARIOCONTATO, DATA, ULTIMA);	
    	repositorio01.atualizarconversa(IDUSUARIO, IDUSUARIOCONTATO, DATA, ULTIMA);
     }    
    
}
