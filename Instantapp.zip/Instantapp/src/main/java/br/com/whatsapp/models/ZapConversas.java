package br.com.whatsapp.models;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "zap_conversas")
public class ZapConversas {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDCONVERSA", nullable = false)	
	private int IDCONVERSA;
	@Column(name = "MENSAGEM", length = 2000,nullable = false)
	private String MENSAGEM; 
	@Column(name = "DATA", nullable = false)
	private Instant DATA; 
	@Column(name = "STATUS", nullable = false)
	private int STATUS;
	@Column(name = "IDUSUARIO", nullable = false)	
	private int IDUSUARIO;	
	@Column(name = "IDUSUARIODESTINATARIO", nullable = false)	
	private int IDUSUARIODESTINATARIO;
	@Column(name = "IDTIPOCONVERSA", nullable = false)	
	private int IDTIPOCONVERSA;
	
   public int getIDUSUARIO() {
		return IDUSUARIO;
	}

	public void setIDUSUARIO(int iDUSUARIO) {
		IDUSUARIO = iDUSUARIO;
	}

	public int getIDUSUARIODESTINATARIO() {
		return IDUSUARIODESTINATARIO;
	}

	public void setIDUSUARIODESTINATARIO(int iDUSUARIODESTINATARIO) {
		IDUSUARIODESTINATARIO = iDUSUARIODESTINATARIO;
	}

	public int getIDTIPOCONVERSA() {
		return IDTIPOCONVERSA;
	}

	public void setIDTIPOCONVERSA(int iDTIPOCONVERSA) {
		IDTIPOCONVERSA = iDTIPOCONVERSA;
	}

	
	
	
	
//	@ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "IDUSUARIO", nullable = false ,referencedColumnName="IDUSUARIO")
//    private SecUsuarios secusuarios;
	
 //   @ManyToOne(fetch = FetchType.LAZY, optional = false)
 //   @JoinColumn(name = "IDUSUARIO", nullable = false ,referencedColumnName="IDUSUARIODESTINATARIO")
 //    private SecUsuarios secusuariosdestinatario;
    
//    @ManyToOne(fetch = FetchType.LAZY, optional = false)
//    @JoinColumn(name = "IDTIPOCONVERSA", nullable = false,referencedColumnName="IDTIPOCONVERSA")
//    private ZapConversasTipos zapconversastipos;

    public ZapConversas() {}

	public int getIDCONVERSA() {
		return IDCONVERSA;
	}

	public void setIDCONVERSA(int iDCONVERSA) {
		IDCONVERSA = iDCONVERSA;
	}

	public String getMENSAGEM() {
		return MENSAGEM;
	}

	public void setMENSAGEM(String mENSAGEM) {
		MENSAGEM = mENSAGEM;
	}

	public Instant getDATA() {
		return DATA;
	}

	public void setDATA(Instant dATA) {
		DATA = dATA;
	}

	public int getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}

//	public SecUsuarios getSecusuarios() {
//		return secusuarios;
//	}

//	public void setSecusuarios(SecUsuarios secusuarios) {
//		this.secusuarios = secusuarios;
//	}

//	public SecUsuarios getSecusuariosdestinatario() {
//		return secusuariosdestinatario;
//	}

//	public void setSecusuariosdestinatario(SecUsuarios secusuariosdestinatario) {
//		this.secusuariosdestinatario = secusuariosdestinatario;
//	}

//	public ZapConversasTipos getZapconversastipos() {
//		return zapconversastipos;
//	}

//	public void setZaptiposmensagens(ZapConversasTipos Zapconversastipos) {
//		this.zapconversastipos = Zapconversastipos;
//	}  	    
    
}
