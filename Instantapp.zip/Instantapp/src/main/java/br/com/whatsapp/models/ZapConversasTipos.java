package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "zap_conversas_tipos")
public class ZapConversasTipos {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDTIPOCONVERSA", nullable = false)
	private int IDTIPOCONVERSA;
	@Column(name = "NOME", length = 50,nullable = false)
	private String NOME; 
	@Column(name = "IMAGEM", length = 250,nullable = false)
	private String IMAGEM;
	@Column(name = "STATUS", nullable = false)
	private int STATUS;
	
    public ZapConversasTipos() {}

	public int getIDTIPOCONVERSA() {
		return IDTIPOCONVERSA;
	}

	public void setIDTIPOCONVERSA(int iDTIPOCONVERSA) {
		IDTIPOCONVERSA = iDTIPOCONVERSA;
	}

	public String getNOME() {
		return NOME;
	}

	public void setNOME(String nOME) {
		NOME = nOME;
	}

	public String getIMAGEM() {
		return IMAGEM;
	}

	public void setIMAGEM(String iMAGEM) {
		IMAGEM = iMAGEM;
	}

	public int getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}
       
}
