package br.com.whatsapp.controllers;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import br.com.whatsapp.models.SecPerfis;
import br.com.whatsapp.repository.sec_perfilRepository;



@RestController
public class sec_perfilController {
	
    @Autowired
    private sec_perfilRepository repositorio01;

     
    @RequestMapping(value = "/perfil", method = RequestMethod.GET)
    public List<SecPerfis> Get() {
        return repositorio01.findAll();
    }

    @RequestMapping(value = "/perfil/{id}", method = RequestMethod.GET)
    public ResponseEntity<SecPerfis> GetById(@PathVariable(value = "id") int IDPERFIL)
    {
        Optional<SecPerfis> perfil = repositorio01.findById(IDPERFIL);
        if(perfil.isPresent())
            return new ResponseEntity<SecPerfis>(perfil.get(), HttpStatus.OK);
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/perfil", method =  RequestMethod.POST)
    public SecPerfis Post(@Valid @RequestBody SecPerfis perfil)
    {
        return repositorio01.save(perfil);
    }

    @RequestMapping(value = "/perfil/{id}", method =  RequestMethod.PUT)
    public ResponseEntity<SecPerfis> Put(@PathVariable(value = "id") int IDPERFIL, @Valid @RequestBody SecPerfis newperfil)
    {
        Optional<SecPerfis> oldperfil = repositorio01.findById(IDPERFIL);
        if(oldperfil.isPresent()){
        	SecPerfis perfil = oldperfil.get();
            perfil.setNOME(newperfil.getNOME());
            perfil.setSTATUS(newperfil.getSTATUS());
            repositorio01.save(perfil);
            return new ResponseEntity<SecPerfis>(perfil, HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/perfil/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Object> Delete(@PathVariable(value = "id") int IDPERFIL)
    {
        Optional<SecPerfis> perfil = repositorio01.findById(IDPERFIL);
        if(perfil.isPresent()){
        	repositorio01.delete(perfil.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}