package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "sec_perfis")
public class SecPerfis {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDPERFIL", nullable = false)
	private int IDPERFIL;
	@Column(name = "FOTO", length = 250,nullable = false)	
	private String FOTO;
	@Column(name = "NOME", length = 50,nullable = false)	
	private String NOME;
	@Column(name = "STATUS", nullable = false)	
	private int STATUS;	
	
    public SecPerfis() {}

	public int getIDPERFIL() {
		return IDPERFIL;
	}
	public void setIDPERFIL(int iDPERFIL) {
		IDPERFIL = iDPERFIL;
	}
	public String getFOTO() {
		return FOTO;
	}
	public void setFOTO(String fOTO) {
		FOTO = fOTO;
	}
	public String getNOME() {
		return NOME;
	}
	public void setNOME(String nOME) {
		NOME = nOME;
	}
	public int getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}	  
    
}
