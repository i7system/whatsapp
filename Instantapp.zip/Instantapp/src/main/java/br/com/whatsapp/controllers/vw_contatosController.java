
package br.com.whatsapp.controllers;

import java.time.Instant;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import br.com.whatsapp.models.SecUsuarios;
import br.com.whatsapp.repository.sec_usuariosRepository;
import br.com.whatsapp.repository.vw_contatosRepository;
import br.com.whatsapp.views.vw_contatos;

@RestController
public class vw_contatosController {
	
   @Autowired
   private vw_contatosRepository repositorio01; 

   @Autowired
   private sec_usuariosRepository repositorio02; 

   
    @RequestMapping(value = "/listarcontatosempresa1", method = RequestMethod.GET)
	public List<vw_contatos> listarcontatosempresa1() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();      
		SecUsuarios usuario =  repositorio02.findByEMAIL(auth.getName()); 
	    return repositorio01.listarcontatosempresa1(usuario.getIDUSUARIO());
	} 

    @RequestMapping(value = "/listarcontatosempresa2", method = RequestMethod.GET)
	public List<vw_contatos> listarcontatosempresa2() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();      
		SecUsuarios usuario =  repositorio02.findByEMAIL(auth.getName()); 
		return repositorio01.listarcontatosempresa2(usuario.getIDUSUARIO());
	} 	

	
	
	
    @RequestMapping(value = "/listarcontatosempresa3", method = RequestMethod.GET)
	public List<vw_contatos> listarcontatosempresa3() {
	    return repositorio01.listarcontatosempresa3();
	} 	
	
	
    @RequestMapping(value = "/listarcontatos", method = RequestMethod.GET)
    @ResponseBody
	public List<vw_contatos> listarcontatosporusuario(@RequestParam("idusuario") int idusuario) {
	    return repositorio01.listarcontatosporusuario(idusuario);
	} 
	
    @RequestMapping(value = "/listarcontatospordata", method = RequestMethod.GET)
    @ResponseBody
	public List<vw_contatos> listarcontatospordata(@RequestParam("idusuario") int idusuario,@RequestParam("data") Instant data) {
	    return repositorio01.listarcontatospordata(idusuario,data);
	} 	
	
}
