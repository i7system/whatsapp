package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "sec_menus")
public class SecMenus {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "IDMENU", nullable = false)
	private int IDMENU;
	@Column(name = "NOME", length = 50,nullable = false)	
	private String NOME; 
	@Column(name = "ORDEM", length = 30,nullable = false)	
	private String ORDEM;
	@Column(name = "URL", length = 250,nullable = false)	
	private String URL; 
	@Column(name = "PARAMETROS", length = 250,nullable = false)	
	private String PARAMETROS; 
	@Column(name = "IMAGEM", length = 250,nullable = false)	
	private String IMAGEM; 
	@Column(name = "NIVEL", nullable = false)	
	private int NIVEL;
	@Column(name = "PAI", length = 30,nullable = false)	
	private String PAI;
	@Column(name = "IDACAOMENU", nullable = false)	
	private int IDACAOMENU;
	@Column(name = "STATUS", nullable = false)	
	private int STATUS;
	
    public SecMenus() {}
	
	public int getIDMENU() {
		return IDMENU;
	}
	public void setIDMENU(int iDMENU) {
		IDMENU = iDMENU;
	}
	public String getNOME() {
		return NOME;
	}
	public void setNOME(String nOME) {
		NOME = nOME;
	}
	public String getORDEM() {
		return ORDEM;
	}
	public void setORDEM(String oRDEM) {
		ORDEM = oRDEM;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	public String getPARAMETROS() {
		return PARAMETROS;
	}
	public void setPARAMETROS(String pARAMETROS) {
		PARAMETROS = pARAMETROS;
	}
	public String getIMAGEM() {
		return IMAGEM;
	}
	public void setIMAGEM(String iMAGEM) {
		IMAGEM = iMAGEM;
	}
	public int getNIVEL() {
		return NIVEL;
	}
	public void setNIVEL(int nIVEL) {
		NIVEL = nIVEL;
	}
	public String getPAI() {
		return PAI;
	}
	public void setPAI(String pAI) {
		PAI = pAI;
	}
	public int getIDACAOMENU() {
		return IDACAOMENU;
	}
	public void setIDACAOMENU(int iDACAOMENU) {
		IDACAOMENU = iDACAOMENU;
	}
	public int getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(int sTATUS) {
		STATUS = sTATUS;
	}			
	
}
