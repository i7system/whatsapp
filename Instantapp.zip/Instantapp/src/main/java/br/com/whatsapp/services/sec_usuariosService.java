package br.com.whatsapp.services;

import br.com.whatsapp.models.SecUsuarios;
import br.com.whatsapp.repository.sec_usuariosRepository;
import br.com.whatsapp.models.SecPerfis;
import br.com.whatsapp.repository.sec_perfilRepository;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import javax.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class sec_usuariosService  {

    private sec_usuariosRepository sec_usuariosRepository;
    private sec_perfilRepository sec_perfisRepository;
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    
	@Autowired
	private sec_usuariosRepository repositorio;

	@Autowired
	EntityManagerFactory emf;
	
    @Autowired
    public sec_usuariosService(sec_usuariosRepository sec_usuariosRepository,
        sec_perfilRepository sec_perfisRepository,
        BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.sec_usuariosRepository = sec_usuariosRepository;
        this.sec_perfisRepository = sec_perfisRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }
    
    public void savesec_usuarios(SecUsuarios sec_usuarios) {

    	sec_usuarios.setSENHA(bCryptPasswordEncoder.encode(sec_usuarios.getSENHA())); 
    	sec_usuarios.setFOTO("img/usuario_vazio.jpg");
    	sec_usuarios.setIDIDIOMA(1);
    	sec_usuarios.setSTATUS(1); 
    	sec_usuarios.setIDCONVERSA(0);
    	sec_usuarios.setIDPAGINA(1);
    	sec_usuarios.setFRASE("Sou um usuario de InstantApp");
    	sec_usuarios.setCPF("000.000.000-00");
    	sec_usuarios.setIDDEPARTAMENTO(1);
    	sec_usuarios.setTOKEN("");
        SecPerfis perfis = sec_perfisRepository.findByNOME("Administrador");
        sec_usuarios.setRoles(new HashSet<SecPerfis>(Arrays.asList(perfis)));   	
        sec_usuariosRepository.save(sec_usuarios);
    } 
    
    
	public void atualizarcoordenadas(float latitude,float longitude) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
        SecUsuarios sec_usuarios;
        sec_usuarios=repositorio.findByEMAIL(auth.getName());	
        sec_usuarios.setLATITUDE(latitude);     
        sec_usuarios.setLONGITUDE(longitude);
        sec_usuariosRepository.save(sec_usuarios);
 	}	

    
    
	public void deletesec_usuarios(int idusuario) { 
	   	repositorio.deleteById(idusuario);
	}
    
    public SecUsuarios findsec_usuariosByEMAIL(String EMAIL) {
        return sec_usuariosRepository.findByEMAIL(EMAIL);
    }    
    
	public SecUsuarios registro() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		return repositorio.findByEMAIL(auth.getName());						
	}	
	

	public List lista() {			
		Pageable paginacao = PageRequest.of(0, 1000, Sort.by("NOME").ascending());
		return repositorio.resultado(paginacao);		
	}
	
    public SecUsuarios findsec_usuariosByIDUSUARIO(int IDUSUARIO) {
        return sec_usuariosRepository.findByIDUSUARIO(IDUSUARIO);
    }            
    
	public List listacompleta(int pagina) {			
		Pageable paginacao = PageRequest.of(pagina, 3, Sort.by("NOME").ascending());
		return repositorio.resultadocompleto(paginacao);		
	}	

	
    public Page<SecUsuarios> listacompleta2(int pagina) {
    	Page<SecUsuarios> page = null;
        PageRequest pageRequest = PageRequest.of(pagina-1, 5,  Sort.Direction.ASC,  "NOME");
         page = repositorio.findAll(pageRequest);     
        return page;
    }

}


