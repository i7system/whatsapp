package br.com.whatsapp.models;

import javax.persistence.*;

@Entity
@Table(name = "sec_menus_perfis")
public class SecMenusPerfis {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int IDMENUPERFIL; 
	
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "IDMENU", nullable = false)
    private SecMenus secmenus;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "IDPERFIL", nullable = false)
    private SecPerfis secperfis;

	public int getIDMENUPERFIL() {
		return IDMENUPERFIL;
	}

	public void setIDMENUPERFIL(int iDMENUPERFIL) {
		IDMENUPERFIL = iDMENUPERFIL;
	}

	public SecMenus getSecmenus() {
		return secmenus;
	}

	public void setSecmenus(SecMenus secmenus) {
		this.secmenus = secmenus;
	}

	public SecPerfis getSecperfis() {
		return secperfis;
	}

	public void setSecperfis(SecPerfis secperfis) {
		this.secperfis = secperfis;
	}	

    public SecMenusPerfis() {}	
	
}
